package com.e.victimhumanhelper;

class Traffic_notification_list {
    String Message;
    String time;

    public String getMessage() {
        return Message;
    }

    public void setMessage(String message) {
        Message = message;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }


}
