package com.e.victimhumanhelper;

class ConstantURL {

    public static final String URL = "http://192.168.43.181/Victim/";
    public static final String PREFERENCE = "pref";
    public static final String ID = "id";
    public static final String NAME = "name";
    public static final String CONTACT = "contact";
    public static final String PASSWORD = "password";
    public static final String AREA = "area";
    public static final String CITY = "city";
    public static final String STATE = "state";
    public static final String EMAIL = "email";
    public static final String TYPE = "type";
}
